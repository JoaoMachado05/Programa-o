public class Sensor {
    private boolean ativado;

    public boolean isAtivado() {
        return ativado;
    }

    public void ativar() {
        this.ativado = true;
    }

    public void desativar() {
        this.ativado = false;
    }
}
