public class SimuladorBRT {
    public static void main(String[] args) {
        // Criar sensores e semáforos
        Sensor sensorAntes = new Sensor();
        Sensor sensorDepois = new Sensor();
        Semaforo semaforoViasAdjacentes = new Semaforo();
        Semaforo semaforoPeoes = new Semaforo();

        // Criar controlador
        ControladorSemaforos controlador = new ControladorSemaforos(
                sensorAntes, sensorDepois, semaforoViasAdjacentes, semaforoPeoes
        );

        // Simular pedido de atravessamento por peões
        controlador.setPedidoPeoes(true);

        // Simular deteção do autocarro antes do cruzamento
        System.out.println(">>> Autocarro BRT aproxima-se do cruzamento...");
        sensorAntes.ativar();

        // Processar lógica do semáforo
        controlador.processar();

        // Simular deteção após o cruzamento (fim da passagem)
        System.out.println(">>> Autocarro BRT já passou o cruzamento...");
        sensorDepois.ativar();
        controlador.processar(); // Esta chamada agora vai confirmar fim da passagem

        // Mostrar estados finais
        System.out.println("\n--- ESTADOS FINAIS ---");
        System.out.println("Semáforo vias adjacentes: " + semaforoViasAdjacentes.getEstado());
        System.out.println("Semáforo peões: " + semaforoPeoes.getEstado());
    }
}
