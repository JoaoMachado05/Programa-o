
public class Semaforo {
    private EstadoSemaforo estado;

    public void setEstado(EstadoSemaforo estado) {
        this.estado = estado;
    }

    public EstadoSemaforo getEstado() {
        return estado;
    }
}