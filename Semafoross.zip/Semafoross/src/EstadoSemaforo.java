public enum EstadoSemaforo {
    VERDE, VERMELHO, INTERMITENTE
}
