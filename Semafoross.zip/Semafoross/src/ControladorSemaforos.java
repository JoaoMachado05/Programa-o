public class ControladorSemaforos {
    private int temporizador;
    private final Semaforo viasAdjacentes;
    private final Semaforo peoes;
    private final Sensor sensorAntes;
    private final Sensor sensorDepois;
    private boolean pedidoPeoes;

    public ControladorSemaforos(Sensor antes, Sensor depois, Semaforo vias, Semaforo peoes) {
        this.sensorAntes = antes;
        this.sensorDepois = depois;
        this.viasAdjacentes = vias;
        this.peoes = peoes;
    }

    public void processar() {
        if (!sensorAntes.isAtivado()) {
            System.out.println("Sensor não detetou autocarro. Estado normal dos semáforos.");
            manterEstadoNormal();
            return;
        }

        System.out.println("Sensor detetou autocarro a 15m do cruzamento.");
        ativarVermelhoViasAdjacentes();
        ativarIntermitentePeoes();
        iniciarTemporizador(7);

        while (temporizador > 0) {
            System.out.println("Temporizador: " + temporizador + "s");
            esperar(1);
            temporizador--;
        }

        System.out.println("Fim da passagem do autocarro.");
        fimPassagem();
    }

    private void ativarVermelhoViasAdjacentes() {
        viasAdjacentes.setEstado(EstadoSemaforo.VERMELHO);
        System.out.println("Semáforo vias adjacentes: VERMELHO");
    }

    private void ativarIntermitentePeoes() {
        peoes.setEstado(EstadoSemaforo.INTERMITENTE);
        System.out.println("Semáforo peões: INTERMITENTE");
    }

    private void iniciarTemporizador(int segundos) {
        this.temporizador = segundos;
        System.out.println("Início do temporizador de interdição: " + segundos + "s");
    }

    private void esperar(int segundos) {
        try {
            Thread.sleep(segundos * 1000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private void fimPassagem() {
        sensorAntes.desativar(); // reset
        viasAdjacentes.setEstado(EstadoSemaforo.VERDE);
        System.out.println("Semáforo vias adjacentes: VERDE");

        if (pedidoPeoes) {
            peoes.setEstado(EstadoSemaforo.VERDE);
            System.out.println("Pedido de atravessamento detetado. Semáforo peões: VERDE");
        } else {
            peoes.setEstado(EstadoSemaforo.INTERMITENTE);
            System.out.println("Sem pedido de peões. Semáforo peões: INTERMITENTE");
        }

        if (sensorDepois.isAtivado()) {
            confirmarFimDaPassagem();
        }
    }

    private void confirmarFimDaPassagem() {
        System.out.println("Sensor após o cruzamento detetou autocarro. Fim da passagem confirmado.");
        System.out.println("Se necessário, antecipar transição dos semáforos.");
        // Aqui podes adicionar lógica futura se precisares.
    }

    private void manterEstadoNormal() {
        viasAdjacentes.setEstado(EstadoSemaforo.VERDE);
        peoes.setEstado(EstadoSemaforo.VERDE);
    }

    public void setPedidoPeoes(boolean pedido) {
        this.pedidoPeoes = pedido;
    }
}
